package com.fly.service.impl;

import com.fly.mapper.FAdminRoleMapper;
import com.fly.model.FAdminRole;
import com.fly.service.RoleListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleListServiceImpl implements RoleListService {

    @Autowired
    private FAdminRoleMapper fAdminRoleMapper;


    @Override
    public List<FAdminRole> roleList() {
        return fAdminRoleMapper.roleList();
    }
}
