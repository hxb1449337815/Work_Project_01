package com.fly.controller;

import com.fly.model.FAdminRole;
import com.fly.service.RoleListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class RoleController {

    @Autowired
    private RoleListService roleListService;

    @RequestMapping("roleList")
    public String roleList(ModelMap map){

        List<FAdminRole> fAdminRoles = roleListService.roleList();
        for (FAdminRole fAdminRole : fAdminRoles) {
            System.out.println(fAdminRole);
        }
        map.addAttribute("roleList",fAdminRoles);
        return "user-group";
    }


    @RequestMapping("byId")


}
