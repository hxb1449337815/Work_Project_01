package com.fly.controller;

import java.util.Date;

public class test {

    public void doBiz()
    {
        System.out.println("执行时间是："+new Date());
    }

}
